from setuptools import setup

setup(
    name="paquete_calculos",
    version="1.0",
    description="Paquete con redondeo y potencia",
    author="Pepe",
    author_email="pepe@pepemail.com",
    packages=["calculos","calculos.redondeo_potencia"]
)